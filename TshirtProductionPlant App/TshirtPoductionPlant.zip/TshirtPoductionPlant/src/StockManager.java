/**
 * @author 215016957@stu.ukzn.ac.za
 * Lindani Ricardo Mabaso - mabasolindaniricardo@gmail.com
 */
public class StockManager {
	/*
	 * Has method to give the available material for given brand
	 * Has method to calculate price
	 */
	private static int materialCost;
	private static int brand;
	private static int material;
	private static int quantity;
	private static double totalPice;
	static String brandName, materialName;
	
	/*enum Brand{
		//List of possible brands
		Adibas, Nikea, Pumba;
	}
	
	enum AdibasMatrial{
		//List of possible material available under different brands
		Silk, Cotton, Polysterene, Denim, Wool;
	}
	*/
	StockManager(){ //Default Constructor
		this.brand = 1;
		this.material=1;
	}
	

	StockManager(int b,int m){ //parameterised constructor
		setBrand(b);
		setMaterial(m);
	}
	
	/*
	 * This method takes in brand name and material available and return
	 * the cost of it.
	 * @param: int brand, int material
	 * @return: material cost
	 */
	public static int getAvailableMaterial() { 
		int material_cost=0;
		int brand = getBrand();
		int material = getMaterial();
		
		if(brand==1) { //If it Adibas
			brandName = "Adibas";
			materialName = "Polystyrene";
			if(material==1 || material==2) {
				materialName = (material > 1) ? "Cotton" :"Silk";
				material_cost= 24; // If Silk or cotton
			}else
				material_cost= 19; //Polystene
				
		}else if(brand==2) {//Nikea
			brandName = "Nikea";
			materialName = "Silk";
			if(material==1) {
				materialName = "Cotton";
				material_cost = 24; //cotton
			}else
				material_cost = 25; //silk
				
		}else if(brand==3) {//Pumba
			brandName = "Pumba";
			materialName = "Wool";
			if(material==1) {
				material_cost =  23; //denim
				materialName = "Denim";
			}else
				material_cost =  27; //wool	
		}
		setMaterialCost(material_cost);
		
		return material_cost;
	}
	
	/*
	 * This method takes quantity and cost and compute the price of 
	 * the product.
	 */
	public static double calculatePrice() {
		setTotalPrice((getQuantity()*getMaterialCost())*(1.4));
		return ((getQuantity()*getMaterialCost())*(1.4));
		
		
	}

	public static int getBrand() {
		return brand;
	}

	public void setBrand(int b) {
		this.brand = b;
	}

	public static int getMaterial() {
		return material;
	}

	public void setMaterial(int ma) {
		this.material = ma;
	}

	public static int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public static int getMaterialCost() {
		return materialCost;
	}
	
	public double getTotalPice() {
		return this.totalPice;
	}
	
	public static void setTotalPrice(double totalPrice){
		totalPice = totalPrice;
	}
	
	public static void setMaterialCost(int m){
		materialCost =  m;
	}
	
	public String toString() {
		String line = String.format("Brand Name: %-10sMaterial Type: %-10sQuantiy: %-5dTotal Price: R%-5.2f",brandName,materialName,getQuantity(),getTotalPice());
		return "\nInventory Data Selected and Total Price: \n"+line;
	}
}
