import java.awt.datatransfer.StringSelection;
import java.util.Scanner;
import javax.print.DocFlavor.INPUT_STREAM;

/**
 * @author 215016957@stu.ukzn.ac.za
 * Lindani Ricardo Mabaso - mabasolindaniricardo@gmail.com
 */
public class Main {

	/*
	 * Contains the main function
	 * Responsible for getting input from the user 
	 */
	
	static Scanner inputfile = new Scanner(System.in);
	static int 	brandName, 
			materialAvailable,
			materialCost,
			quantity; 
	static double  finalPrice;
	
	
	public static void main(String[] args) {
		displayInputOptions();
		StockManager stockmanager = new StockManager(brandName,materialAvailable); // Instantiate Object
		materialCost 	= StockManager.getAvailableMaterial(); // Get the cost of the selected material
		stockmanager.setQuantity(quantity); //set quantity required
		stockmanager.setMaterialCost(materialCost); //Cost of relative material
		
		finalPrice 		= StockManager.calculatePrice(); //final price
		System.out.println(stockmanager.toString()); //Rsults output
	}
	
	/*
	 * This function displays the input wizard allowing you to select options available to minimize errors
	 */
	public static void displayInputOptions() {
		
		System.out.println("========= T-shirt Production Plant =========");
		do {
			System.out.println("Please select a Brand\n1) Adibas\n2) Nikea \n3) Pumba");
			brandName = inputfile.nextInt();
		} while(brandName<1 || brandName>3);
		
		switch(brandName) {
			case 1://If it Adibas
				System.out.println("Select a Material:\n1) Silk\n2) Cotton \n3) Polystyrene");
				break;
			case 2://Nikea
				System.out.println("Select a Mateial:\n1) Cotton\n2) Silk");
				break;
			default://Pumba
				System.out.println("Select a Material:\n1) Demin\n2) Wool ");
				break;
			
		}
		materialAvailable = inputfile.nextInt();
		System.out.println(materialAvailable+" Enter Quantity: ");
		quantity = inputfile.nextInt();
	}
}
